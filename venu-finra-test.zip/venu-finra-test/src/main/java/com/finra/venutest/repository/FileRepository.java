package com.finra.venutest.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.finra.venutest.model.FinraFile;

@Repository
public interface FileRepository extends JpaRepository<FinraFile, Long>{

	List<FinraFile> fetchByLastDate(@Param("givenDate") Date givenDate);
}
