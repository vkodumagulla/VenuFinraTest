package com.finra.venutest.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.finra.venutest.model.FinraFile;
import com.finra.venutest.service.FileService;

@RestController
public class FileController {

	@Autowired
	FileService fileService;
	
	@GetMapping("/finra/files/file/id/{id}")
	public Optional<FinraFile> getFile(@PathVariable Long id){
		Optional<FinraFile> returnFile=fileService.getFileById(id);
		return returnFile;
	}
	@GetMapping("/finra/files")
	public List<FinraFile> getFiles(){
		List<FinraFile> returnFile=fileService.getAllFiles();
		return returnFile;
	}
	
	@GetMapping("/finra/files/lastHour")
	public List<FinraFile> getFilesByHour(){
		Date time=new Date(Calendar.getInstance().getTimeInMillis()-1/24);
		List<FinraFile> returnFile=fileService.getAllFilesByHour(time);
		return returnFile;
	}
	@PostMapping("/finra/files/file/name/{name}/type/{type}")
	public FinraFile storeFile(@PathVariable String name, @PathVariable String type){
		
		FinraFile saveFile=new FinraFile();
		saveFile.setName(name);
		saveFile.setType(type);
		saveFile.setCreateDate(Calendar.getInstance().getTime());
		saveFile=fileService.createFile(saveFile);
		return saveFile;
	}
}
