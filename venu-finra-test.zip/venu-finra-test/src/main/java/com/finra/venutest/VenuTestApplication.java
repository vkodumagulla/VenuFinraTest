package com.finra.venutest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VenuTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(VenuTestApplication.class, args);
	}
}
