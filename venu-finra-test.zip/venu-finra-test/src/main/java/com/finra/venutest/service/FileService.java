package com.finra.venutest.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.finra.venutest.model.FinraFile;
import com.finra.venutest.repository.FileRepository;

@Service
public class FileService {

	@Autowired
	FileRepository fileRepository;
	public Optional<FinraFile> getFileById(Long id){
		Optional<FinraFile> returnFile=fileRepository.findById(id);
		return returnFile;
	}

	public List<FinraFile> getAllFiles(){
		List<FinraFile> returnFile=fileRepository.findAll();
		return returnFile;
	}
	
	public List<FinraFile> getAllFilesByHour(Date time){
		List<FinraFile> returnFile=fileRepository.fetchByLastDate(time);
		return returnFile;
	}
	public FinraFile createFile(FinraFile saveFile){
		
		saveFile.setCreateDate(Calendar.getInstance().getTime());
		saveFile=fileRepository.save(saveFile);
		return saveFile;
	}
}
