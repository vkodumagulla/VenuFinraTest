package com.finra.venutest;

import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.finra.venutest.controller.FileController;
import com.finra.venutest.model.FinraFile;
import com.finra.venutest.service.FileService;
import com.finra.venutest.util.TestUtil;

//@RunWith(MockitoJUnitRunner.class)
//@WebAppConfiguration
@RunWith(SpringRunner.class)
@WebMvcTest(FileController.class)
public class VenuTestApplicationTests {

	@Autowired
	private MockMvc mockMvc;
	
	@Mock
	FileService fileService;
	
	@InjectMocks
	private FileController fileController;
	
	@Test
    public void findById_TodoEntryFound_ShouldReturnFoundTodoEntry() throws Exception {
		Optional<FinraFile> found = Optional.of(new FinraFile(1l, "Venu", "XXX"));

               
 
        when((fileService).getFileById(1L)).thenReturn(found);
 
        mockMvc.perform(get("/finra/files/file/id/{id}", 1L))
                .andExpect(status().isOk())
                .andExpect(content().contentType(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("Venu")))
                .andExpect(jsonPath("$.type", is("XXX")));
 
        verify(fileService, times(1)).getFileById(1L);
        verifyNoMoreInteractions(fileService);
    }


}
